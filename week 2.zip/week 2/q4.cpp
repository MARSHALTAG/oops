//4. Write a C++ program to generate the first n terms of the Fibonacci sequence. 

#include <iostream>
using namespace std;

int main() {
    int f0 = 0, f1 = 1, f2;
    int n;

    cout << "Enter n: ";
    cin >> n;

    cout << "Fibonacci series are: ";

    cout << f0 << " " << f1 << " ";

    for (int i = 2; i < n; i++) {
        f2 = f0 + f1;
        f0 = f1;
        f1 = f2;

        cout << f2 << " ";
    }

    return 0;
}
