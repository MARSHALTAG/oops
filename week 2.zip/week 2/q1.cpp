/*#include <iostream>
using namespace std;

int main(){
	int n,i,j;
	cout <<"enter n:";
	cin >>n;
	
	for (int i=n;i>=j;i--){
		for (int j=1;j<=i;j++){
			cout <<"*";
		}
		cout <<endl;
	}
return 0;
}
*/

/*#include <iostream>
using namespace std;

int main(){
	int  n,i,j;
	
	cout <<"enter input:";
	cin >>n;
	
	for (int i=n;i>=j;i--){
		for (int j=1;j<=i;j++){
			cout <<char('A'+j-1);
		}
		cout <<endl;
	}
return 0;
}
*/


#include <iostream>
using namespace std;

int main(){
	int i,j,n,num=1;
	cout <<"enter no:";
	cin >>n;
	
	for (int i=1;i<=n;i++){
		for (int j=1;j<=i;j++){
			cout <<num;
			num++;
			
		}
		cout<<endl;
	}
return 0;
}
