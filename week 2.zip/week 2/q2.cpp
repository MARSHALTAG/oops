//2. Write a C++ program to check whether the given number is a perfect cube or not 
//(without using any in-built/library function). Display the proper message 
//accordingly.


#include <iostream>
using namespace std;

int main() {
    int i, n, p;

    cout << "Enter no to check: ";
    cin >> n;

    for (i = 1; i * i * i <= n; i++) {
        p = i * i * i;

        if (n == p) {
            cout << "Perfect cube";
            cout << "\nCube root = " << i;
            return 0;
        }
    }

    cout << "Not a perfect cube";

    return 0;
}
