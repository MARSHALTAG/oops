//7. Define a structure to represent the bank account of a customer, where the members 
//are Customer name, Account number, Account type (Savings, Fixed or Current) and 
//balance amount. Perform the following operations: 
//i. Deposit an amount. 
//ii. Withdraw an amount after checking the balance. 
//
//

#include <iostream>
using namespace std;

int main() {
    int bill, paid, balance;

    cout << "Enter total bill: ";
    cin >> bill;

    cout << "Enter cash paid: ";
    cin >> paid;

    balance = paid - bill;

    cout << "Balance = " << balance << endl;
    cout << "Coins/Notes required: ";

    int denominations[] = {200, 100, 50, 20, 10, 5, 2, 1};

    for (int i = 0; i < 8; i++) {
        while (balance >= denominations[i]) {
            cout << denominations[i] << " ";
            balance = balance - denominations[i];
        }
    }

    return 0;
}
