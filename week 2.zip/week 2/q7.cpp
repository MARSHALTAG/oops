////7. Define a structure to represent the bank account of a customer, where the members
////are Customer name, Account number, Account type (Savings, Fixed or Current) and
////balance amount. Perform the following operations:
////i. Deposit an amount.
////ii. Withdraw an amount after checking the balance.
//
//#include <iostream>
//using namespace  std;
//
//struct bankacc{
//	string name;
//	int accno;
//	string acctype;
//	int bal=0;
//};
//void deposit(bankacc&,int);
//void withdraw(bankacc&,int);
//
//int main(){
//	int amount;
//	bankacc b;
//	cout<<"enter name\n";
//	cin>>b.name;
//	cout<<"enter accno\n";
//	cin>>b.accno;
//	cout<<"enter acctype\n";
//	cin>>b.acctype;
//	cout<<"enter amount\n";
//	cin>>amount;
//	deposit(b,amount);
//	cout<<"amount deposited successfuly\n";
//	withdraw(b,amount);
//	cout<<"amount withdrwn";
//
//return 0;
//}
//
//void deposit(bankacc &b,int amount){
//	b.bal=b.bal+amount;
//	cout<<b.bal;
//}
//
//void withdraw(bankacc &b,int amount){
//	b.bal=b.bal-amount;
//	cout<<"after withdrawing\t";
//	cout<<b.bal;
//}
//
//




#include <iostream>
using namespace std;

struct bankacc {
    string name;
    int accno;
    string acctype;
    int bal = 0;
};

void deposit(bankacc&, int);
void withdraw(bankacc&, int);

int main() {
    int amount;
    bankacc b;

    cout << "Enter name\n";
    cin >> b.name;

    cout << "Enter accno\n";
    cin >> b.accno;

    cout << "Enter acctype\n";
    cin >> b.acctype;

    cout << "Enter amount to deposit\n";
    cin >> amount;

    deposit(b, amount);

    cout << "Enter amount to withdraw\n";
    cin >> amount;

    withdraw(b, amount);

    return 0;
}

void deposit(bankacc &b, int amount) {
    b.bal = b.bal + amount;
    cout << "Amount deposited successfully\n";
    cout << "Balance = " << b.bal << endl;
}

void withdraw(bankacc &b, int amount) {
    if (amount <= b.bal) {
        b.bal = b.bal - amount;
        cout << "Amount withdrawn successfully\n";
        cout << "Balance = " << b.bal << endl;
    } else {
        cout << "Insufficient balance";
    }
}


