//5. Write a  C++ program to generate prime numbers between two limits.


#include <iostream>
using namespace std;

int main() {
    int lower, upper;

    cout << "Enter lower limit: ";
    cin >> lower;

    cout << "Enter upper limit: ";
    cin >> upper;

    for (int num = lower; num <= upper; num++) {

        if (num < 2)
            continue;

        bool prime = true;

        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                prime = false;
                break;
            }
        }

        if (prime)
            cout << num << " ";
    }

    return 0;
}
