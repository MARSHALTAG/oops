// Write a C++ program to convert a decimal number to its equivalent binary format. 
//(Example: 25 would be 11001) and vice versa. 

#include <iostream>
using namespace std;

int main() {
    int n, binary, rem, place;
    int decimal, binaryNum;

    // Decimal to Binary
    cout << "Enter decimal number: ";
    cin >> n;

    binary = 0;
    place = 1;

    while (n > 0) {
        rem = n % 2;
        binary = binary + rem * place;
        n = n / 2;
        place = place * 10;
    }

    cout << "Binary = " << binary << endl;


    // Binary to Decimal
    cout << "\nEnter binary number: ";
    cin >> binaryNum;

    decimal = 0;
    place = 1;

    while (binaryNum > 0) {
        rem	 = binaryNum % 10;
        decimal = decimal + rem * place;
        binaryNum = binaryNum / 10;
        place = place * 2;
    }

    cout << "Decimal = " << decimal << endl;

    return 0;
}
